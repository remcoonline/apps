
import { DateInfo } from '../types';

export const calculateDateInfo = (dueDay: number): DateInfo => {
  const today = new Date();
  today.setHours(0, 0, 0, 0); // Normalize to start of day

  let dueDateThisMonth = new Date(today.getFullYear(), today.getMonth(), dueDay);
  
  let nextDueDate: Date;
  if (today.getDate() > dueDay) {
    // Due date for this month has passed, so it's next month
    nextDueDate = new Date(today.getFullYear(), today.getMonth() + 1, dueDay);
  } else {
    // Due date is this month
    nextDueDate = dueDateThisMonth;
  }

  const timeDiff = nextDueDate.getTime() - today.getTime();
  const daysUntilDue = Math.ceil(timeDiff / (1000 * 3600 * 24));
  
  const isOverdue = today.getDate() > dueDay && daysUntilDue < 25; // Simple overdue logic

  return { nextDueDate, daysUntilDue, isOverdue };
};
