
import { GoogleGenAI } from "@google/genai";
import { CreditCard } from '../types';

export async function getFinancialInsights(cards: CreditCard[], prompt: string): Promise<string> {
    if (!process.env.API_KEY) {
        return "API_KEY is not configured. Please set up your environment variables.";
    }

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        
        const cardsData = JSON.stringify(cards.map(c => ({
            name: c.name,
            balance: c.balance,
            minPayment: c.minPayment,
            dueDay: c.dueDay
        })), null, 2);

        const fullPrompt = `
          You are a helpful financial assistant for a credit card tracking application.
          Analyze the user's credit card data and answer their question.
          Be concise, helpful, and provide actionable advice.
          Today's date is ${new Date().toLocaleDateString()}.

          USER'S CREDIT CARD DATA:
          ${cardsData}

          USER'S QUESTION:
          "${prompt}"

          YOUR RESPONSE:
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: fullPrompt,
        });

        return response.text;

    } catch (error) {
        console.error("Error calling Gemini API:", error);
        if (error instanceof Error) {
            return `An error occurred while contacting the AI assistant: ${error.message}`;
        }
        return "An unknown error occurred while contacting the AI assistant.";
    }
}
