
import React, { useState, useMemo } from 'react';
import { CreditCard } from './types';
import { useLocalStorage } from './hooks/useLocalStorage';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import Summary from './components/Summary';
import AddEditCardModal from './components/AddEditCardModal';
import ImportModal from './components/ImportModal';
import AiAssistant from './components/AiAssistant';

const App: React.FC = () => {
  const [cards, setCards] = useLocalStorage<CreditCard[]>('creditCards', []);
  const [isAddEditModalOpen, setIsAddEditModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isAiAssistantOpen, setIsAiAssistantOpen] = useState(false);
  const [editingCard, setEditingCard] = useState<CreditCard | null>(null);

  const handleAddClick = () => {
    setEditingCard(null);
    setIsAddEditModalOpen(true);
  };

  const handleEditClick = (card: CreditCard) => {
    setEditingCard(card);
    setIsAddEditModalOpen(true);
  };

  const handleDeleteClick = (id: string) => {
    if (window.confirm('Are you sure you want to delete this card?')) {
      setCards(cards.filter(card => card.id !== id));
    }
  };

  const handleSaveCard = (card: CreditCard) => {
    if (editingCard) {
      setCards(cards.map(c => c.id === card.id ? card : c));
    } else {
      setCards([...cards, card]);
    }
    setIsAddEditModalOpen(false);
    setEditingCard(null);
  };

  const summaryData = useMemo(() => {
    return {
      totalBalance: cards.reduce((acc, card) => acc + card.balance, 0),
      totalMinPayment: cards.reduce((acc, card) => acc + card.minPayment, 0),
      cardCount: cards.length,
    };
  }, [cards]);

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 font-sans">
      <Header 
        onAddCard={handleAddClick} 
        onImport={ () => setIsImportModalOpen(true) }
        onToggleAi={ () => setIsAiAssistantOpen(!isAiAssistantOpen) }
      />
      <main className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
        <Summary data={summaryData} />
        <Dashboard 
          cards={cards} 
          onEdit={handleEditClick} 
          onDelete={handleDeleteClick} 
        />
      </main>
      
      {isAddEditModalOpen && (
        <AddEditCardModal 
          card={editingCard} 
          onClose={() => setIsAddEditModalOpen(false)} 
          onSave={handleSaveCard} 
        />
      )}

      {isImportModalOpen && (
        <ImportModal
          existingCards={cards}
          onClose={() => setIsImportModalOpen(false)}
          onImport={(updatedCards) => {
            setCards(updatedCards);
            setIsImportModalOpen(false);
          }}
        />
      )}

      <AiAssistant 
        isOpen={isAiAssistantOpen}
        onClose={() => setIsAiAssistantOpen(false)}
        cards={cards}
      />
    </div>
  );
};

export default App;
