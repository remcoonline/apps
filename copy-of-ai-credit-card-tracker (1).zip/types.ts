
export interface CreditCard {
  id: string;
  name: string;
  openDate: string; // YYYY-MM-DD
  dueDay: number; // 1-31
  balance: number;
  minPayment: number;
  lastUpdated: string; // ISO string
}

export interface DateInfo {
  nextDueDate: Date;
  daysUntilDue: number;
  isOverdue: boolean;
}
