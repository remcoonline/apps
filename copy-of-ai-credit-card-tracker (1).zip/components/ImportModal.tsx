
import React, { useState } from 'react';
import { CreditCard } from '../types';
import { XIcon, UploadIcon } from './icons';

interface ImportModalProps {
  existingCards: CreditCard[];
  onClose: () => void;
  onImport: (updatedCards: CreditCard[]) => void;
}

const ImportModal: React.FC<ImportModalProps> = ({ existingCards, onClose, onImport }) => {
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState<string>('');
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFile(e.target.files[0]);
      setError('');
    }
  };

  const handleImport = () => {
    if (!file) {
      setError('Please select a file to import.');
      return;
    }
    
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      if (!text) {
        setError("Could not read file.");
        return;
      }

      try {
        const lines = text.split('\n').slice(1); // Skip header row
        const updatedCards = [...existingCards];
        let changesMade = 0;

        lines.forEach((line, index) => {
            if (!line.trim()) return;
            const [name, balanceStr, minPaymentStr] = line.split(',').map(s => s.trim());
            
            if (!name || !balanceStr || !minPaymentStr) {
                throw new Error(`Invalid data on row ${index + 2}. Each row must have Card Name, Balance, and Minimum Payment.`);
            }

            const balance = parseFloat(balanceStr);
            const minPayment = parseFloat(minPaymentStr);

            if (isNaN(balance) || isNaN(minPayment)) {
                throw new Error(`Invalid number format on row ${index + 2}.`);
            }

            const cardIndex = updatedCards.findIndex(c => c.name.toLowerCase() === name.toLowerCase());
            if (cardIndex !== -1) {
                updatedCards[cardIndex] = {
                    ...updatedCards[cardIndex],
                    balance,
                    minPayment,
                    lastUpdated: new Date().toISOString()
                };
                changesMade++;
            }
        });

        if (changesMade > 0) {
            onImport(updatedCards);
        } else {
            setError("No matching card names found in the CSV file. No changes were made.");
        }
      } catch (err) {
        if (err instanceof Error) {
            setError(err.message);
        } else {
            setError("An unknown error occurred during parsing.");
        }
      }
    };
    reader.onerror = () => setError("Failed to read the file.");
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex justify-center items-center">
      <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-lg m-4 relative">
        <button onClick={onClose} className="absolute top-3 right-3 text-slate-400 hover:text-slate-600">
            <XIcon className="h-6 w-6" />
        </button>
        <h2 className="text-2xl font-bold mb-4 text-slate-800">Import Statements</h2>
        <div className="bg-blue-50 border-l-4 border-blue-400 p-4 mb-6">
            <p className="text-sm text-blue-700">
                Upload a CSV file with the headers: <code className="font-mono bg-blue-100 p-1 rounded">Card Name,Current Balance,Minimum Payment</code>. The app will update existing cards that match the 'Card Name'.
            </p>
        </div>
        
        <div className="mt-2 flex justify-center px-6 pt-5 pb-6 border-2 border-slate-300 border-dashed rounded-md">
            <div className="space-y-1 text-center">
                <UploadIcon className="mx-auto h-12 w-12 text-slate-400" />
                <div className="flex text-sm text-slate-600">
                    <label htmlFor="file-upload" className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500">
                        <span>Upload a file</span>
                        <input id="file-upload" name="file-upload" type="file" className="sr-only" accept=".csv" onChange={handleFileChange} />
                    </label>
                    <p className="pl-1">or drag and drop</p>
                </div>
                <p className="text-xs text-slate-500">{file ? file.name : 'CSV up to 10MB'}</p>
            </div>
        </div>

        {error && <p className="text-red-500 text-sm mt-4">{error}</p>}
        
        <div className="mt-6 flex justify-end space-x-3">
          <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 border border-slate-300 rounded-md hover:bg-slate-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-slate-500">Cancel</button>
          <button onClick={handleImport} className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-blue-300" disabled={!file}>
            Import Data
          </button>
        </div>
      </div>
    </div>
  );
};

export default ImportModal;
