
import React, { useState, useRef, useEffect } from 'react';
import { CreditCard } from '../types';
import { getFinancialInsights } from '../services/geminiService';
import { SparklesIcon, XIcon, PaperAirplaneIcon, CubeTransparentIcon } from './icons';

interface AiAssistantProps {
  isOpen: boolean;
  onClose: () => void;
  cards: CreditCard[];
}

interface Message {
  sender: 'user' | 'ai';
  text: string;
}

const AiAssistant: React.FC<AiAssistantProps> = ({ isOpen, onClose, cards }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages]);

  const handleSend = async (prompt?: string) => {
    const userMessage = prompt || input;
    if (!userMessage.trim()) return;

    setInput('');
    setIsLoading(true);
    setMessages(prev => [...prev, { sender: 'user', text: userMessage }]);
    
    try {
      const aiResponse = await getFinancialInsights(cards, userMessage);
      setMessages(prev => [...prev, { sender: 'ai', text: aiResponse }]);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "An unknown error occurred.";
      setMessages(prev => [...prev, { sender: 'ai', text: `Error: ${errorMessage}` }]);
    } finally {
      setIsLoading(false);
    }
  };
  
  const examplePrompts = [
    "Which card should I pay off first?",
    "Summarize my total debt.",
    "Draft an email reminder for my upcoming payments."
  ];

  if (!isOpen) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50 w-[90vw] max-w-md h-[70vh] max-h-[600px] flex flex-col">
      <div className="flex-grow bg-white rounded-t-lg shadow-2xl flex flex-col">
        <header className="flex items-center justify-between p-4 bg-blue-600 text-white rounded-t-lg">
          <div className="flex items-center">
            <SparklesIcon className="h-6 w-6 mr-2" />
            <h2 className="text-lg font-semibold">AI Financial Assistant</h2>
          </div>
          <button onClick={onClose} className="text-blue-200 hover:text-white">
            <XIcon className="h-6 w-6" />
          </button>
        </header>

        <div className="flex-1 p-4 overflow-y-auto space-y-4">
          {messages.length === 0 && (
            <div className="text-center text-slate-500 mt-8">
              <p className="mb-4">Ask me anything about your finances!</p>
              <div className="space-y-2">
                {examplePrompts.map(prompt => (
                   <button 
                     key={prompt}
                     onClick={() => handleSend(prompt)}
                     className="w-full text-left text-sm p-3 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
                   >
                     {prompt}
                   </button>
                ))}
              </div>
            </div>
          )}
          {messages.map((msg, index) => (
            <div key={index} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`p-3 rounded-lg max-w-xs md:max-w-sm ${msg.sender === 'user' ? 'bg-blue-500 text-white' : 'bg-slate-200 text-slate-800'}`}>
                <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
               <div className="p-3 rounded-lg bg-slate-200 text-slate-800 flex items-center">
                 <CubeTransparentIcon className="h-5 w-5 animate-spin mr-2" />
                 <p className="text-sm">Thinking...</p>
               </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <div className="p-4 border-t border-slate-200">
          <div className="flex items-center space-x-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && !isLoading && handleSend()}
              placeholder="Ask a question..."
              className="flex-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              disabled={isLoading}
            />
            <button
              onClick={() => handleSend()}
              disabled={isLoading || !input.trim()}
              className="p-2 rounded-full text-white bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <PaperAirplaneIcon className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AiAssistant;
