
import React from 'react';
import { CreditCard } from '../types';
import CardRow from './CardRow';
import { InfoIcon } from './icons';

interface DashboardProps {
  cards: CreditCard[];
  onEdit: (card: CreditCard) => void;
  onDelete: (id: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ cards, onEdit, onDelete }) => {
  if (cards.length === 0) {
    return (
      <div className="text-center bg-white p-12 rounded-lg shadow">
        <InfoIcon className="mx-auto h-12 w-12 text-slate-400" />
        <h3 className="mt-2 text-lg font-medium text-slate-900">No credit cards added yet</h3>
        <p className="mt-1 text-sm text-slate-500">Click "Add Card" to get started.</p>
      </div>
    );
  }

  return (
    <div className="bg-white shadow-lg rounded-lg overflow-hidden">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-slate-200">
          <thead className="bg-slate-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Card Name</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Current Balance</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Min. Payment</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Next Due Date</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Days Until Due</th>
              <th scope="col" className="relative px-6 py-3">
                <span className="sr-only">Actions</span>
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-slate-200">
            {cards.sort((a,b) => a.name.localeCompare(b.name)).map(card => (
              <CardRow key={card.id} card={card} onEdit={onEdit} onDelete={onDelete} />
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Dashboard;
