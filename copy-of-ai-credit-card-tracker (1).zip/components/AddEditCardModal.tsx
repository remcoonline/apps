
import React, { useState, useEffect } from 'react';
import { CreditCard } from '../types';
import { XIcon } from './icons';

interface AddEditCardModalProps {
  card: CreditCard | null;
  onClose: () => void;
  onSave: (card: CreditCard) => void;
}

const AddEditCardModal: React.FC<AddEditCardModalProps> = ({ card, onClose, onSave }) => {
  const [formData, setFormData] = useState({
    name: '',
    openDate: '',
    dueDay: '',
    balance: '',
    minPayment: '',
  });

  useEffect(() => {
    if (card) {
      setFormData({
        name: card.name,
        openDate: card.openDate,
        dueDay: card.dueDay.toString(),
        balance: card.balance.toString(),
        minPayment: card.minPayment.toString(),
      });
    }
  }, [card]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const dueDayNum = parseInt(formData.dueDay, 10);
    if (isNaN(dueDayNum) || dueDayNum < 1 || dueDayNum > 31) {
        alert("Due day must be a number between 1 and 31.");
        return;
    }

    const newCard: CreditCard = {
      id: card ? card.id : new Date().toISOString(),
      name: formData.name,
      openDate: formData.openDate,
      dueDay: dueDayNum,
      balance: parseFloat(formData.balance) || 0,
      minPayment: parseFloat(formData.minPayment) || 0,
      lastUpdated: new Date().toISOString(),
    };
    onSave(newCard);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex justify-center items-center">
      <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md m-4 relative animate-fade-in-up">
        <button onClick={onClose} className="absolute top-3 right-3 text-slate-400 hover:text-slate-600">
          <XIcon className="h-6 w-6" />
        </button>
        <h2 className="text-2xl font-bold mb-6 text-slate-800">{card ? 'Edit Card' : 'Add a New Card'}</h2>
        <form onSubmit={handleSubmit}>
          <div className="space-y-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-slate-700">Card Name</label>
              <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} required className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" />
            </div>
            <div className="grid grid-cols-2 gap-4">
                <div>
                  <label htmlFor="balance" className="block text-sm font-medium text-slate-700">Current Balance ($)</label>
                  <input type="number" name="balance" id="balance" value={formData.balance} onChange={handleChange} required min="0" step="0.01" className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" />
                </div>
                <div>
                  <label htmlFor="minPayment" className="block text-sm font-medium text-slate-700">Minimum Payment ($)</label>
                  <input type="number" name="minPayment" id="minPayment" value={formData.minPayment} onChange={handleChange} required min="0" step="0.01" className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" />
                </div>
            </div>
             <div className="grid grid-cols-2 gap-4">
                <div>
                    <label htmlFor="dueDay" className="block text-sm font-medium text-slate-700">Monthly Due Day (1-31)</label>
                    <input type="number" name="dueDay" id="dueDay" value={formData.dueDay} onChange={handleChange} required min="1" max="31" className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" />
                </div>
                <div>
                  <label htmlFor="openDate" className="block text-sm font-medium text-slate-700">Account Open Date</label>
                  <input type="date" name="openDate" id="openDate" value={formData.openDate} onChange={handleChange} required className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" />
                </div>
             </div>
          </div>
          <div className="mt-8 flex justify-end space-x-3">
            <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 border border-slate-300 rounded-md hover:bg-slate-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-slate-500">Cancel</button>
            <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">Save Card</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddEditCardModal;
