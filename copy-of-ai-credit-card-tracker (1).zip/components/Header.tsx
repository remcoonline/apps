
import React from 'react';
import { CreditCardIcon, PlusIcon, UploadIcon, SparklesIcon } from './icons';

interface HeaderProps {
  onAddCard: () => void;
  onImport: () => void;
  onToggleAi: () => void;
}

const Header: React.FC<HeaderProps> = ({ onAddCard, onImport, onToggleAi }) => {
  return (
    <header className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <CreditCardIcon className="h-8 w-8 text-blue-600" />
            <h1 className="ml-3 text-2xl font-bold text-slate-800">AI Credit Card Tracker</h1>
          </div>
          <div className="flex items-center space-x-2 sm:space-x-3">
            <button
              onClick={onToggleAi}
              className="flex items-center justify-center p-2 rounded-full text-slate-500 hover:bg-blue-100 hover:text-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              title="AI Assistant"
            >
              <SparklesIcon className="h-6 w-6" />
               <span className="sr-only sm:not-sr-only sm:ml-2">AI Assistant</span>
            </button>
            <button
              onClick={onImport}
              className="hidden sm:flex items-center justify-center px-4 py-2 border border-slate-300 rounded-md shadow-sm text-sm font-medium text-slate-700 bg-white hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <UploadIcon className="h-5 w-5 mr-2" />
              Import
            </button>
             <button
              onClick={onAddCard}
              className="flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <PlusIcon className="h-5 w-5 mr-0 sm:mr-2" />
              <span className="hidden sm:inline">Add Card</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
