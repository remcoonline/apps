
import React from 'react';
import { CreditCard } from '../types';
import { calculateDateInfo } from '../services/dateService';
import { PencilIcon, TrashIcon } from './icons';

interface CardRowProps {
  card: CreditCard;
  onEdit: (card: CreditCard) => void;
  onDelete: (id: string) => void;
}

const CardRow: React.FC<CardRowProps> = ({ card, onEdit, onDelete }) => {
  const { nextDueDate, daysUntilDue, isOverdue } = calculateDateInfo(card.dueDay);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
  };
  
  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };
  
  const daysUntilDueClass = daysUntilDue <= 3 ? 'text-red-600 font-bold' 
                          : daysUntilDue <= 7 ? 'text-yellow-600 font-semibold' 
                          : 'text-green-600';

  return (
    <tr className={isOverdue && card.balance > 0 ? 'bg-red-50' : ''}>
      <td className="px-6 py-4 whitespace-nowrap">
        <div className="text-sm font-medium text-slate-900">{card.name}</div>
        <div className="text-xs text-slate-500">Last updated: {new Date(card.lastUpdated).toLocaleDateString()}</div>
      </td>
      <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-700 font-semibold">{formatCurrency(card.balance)}</td>
      <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">{formatCurrency(card.minPayment)}</td>
      <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">{formatDate(nextDueDate)}</td>
      <td className={`px-6 py-4 whitespace-nowrap text-sm ${daysUntilDueClass}`}>
        {isOverdue && card.balance > 0 ? <span className="font-bold text-red-700">OVERDUE</span> : `${daysUntilDue} days`}
      </td>
      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
        <div className="flex items-center justify-end space-x-4">
            <button onClick={() => onEdit(card)} className="text-blue-600 hover:text-blue-900" title="Edit">
                <PencilIcon className="h-5 w-5" />
            </button>
            <button onClick={() => onDelete(card.id)} className="text-red-600 hover:text-red-900" title="Delete">
                <TrashIcon className="h-5 w-5" />
            </button>
        </div>
      </td>
    </tr>
  );
};

export default CardRow;
