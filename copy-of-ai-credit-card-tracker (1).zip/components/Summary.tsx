
import React from 'react';

interface SummaryProps {
  data: {
    totalBalance: number;
    totalMinPayment: number;
    cardCount: number;
  };
}

const SummaryCard: React.FC<{ title: string; value: string; }> = ({ title, value }) => (
  <div className="bg-white p-6 rounded-lg shadow">
    <h3 className="text-sm font-medium text-slate-500 truncate">{title}</h3>
    <p className="mt-1 text-3xl font-semibold text-slate-900">{value}</p>
  </div>
);

const Summary: React.FC<SummaryProps> = ({ data }) => {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
  };

  return (
    <div className="mb-8">
      <h2 className="text-xl font-semibold text-slate-700 mb-4">Dashboard Overview</h2>
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-3">
        <SummaryCard title="Total Balance" value={formatCurrency(data.totalBalance)} />
        <SummaryCard title="Total Minimum Payments" value={formatCurrency(data.totalMinPayment)} />
        <SummaryCard title="Active Cards" value={data.cardCount.toString()} />
      </div>
    </div>
  );
};

export default Summary;
